package com.redfern.java_course_spring_2021.SpringBootWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
